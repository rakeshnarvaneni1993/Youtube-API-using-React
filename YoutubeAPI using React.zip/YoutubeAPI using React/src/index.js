import _ from "lodash";
import React from "react";
import ReactDOM from "react-dom";
import Videoslist from "./components/videolist";
import SearchBar from "./components/SearchBar";
import CurrentVideo from "./components/currentvideo";
import YTsearch from "youtube-api-search";
const apiKey = "AIzaSyBwpDtwm3ODJ6bd7QulPvLvKBQd5yjQXwo";

class Helloworld extends React.Component{
  constructor(props){
    super(props)
    this.state = {
      videos: [],
      selectedVideo:null,
      searchterm:"rakesh",
    };
    this.videosearch("puppies")
}
videosearch(term){
  YTsearch({key:apiKey,term:term},(data) => {
  this.setState({
    videos: data,
    selectedVideo:data[3]
  })
}

)
}
  render(){
    const vid = _.debounce((term) => {this.videosearch(this.state.searchterm)},300);
    return (
      <div>
        <SearchBar onsearch = { (searchterm) => {
          this.setState({searchterm:searchterm});
          vid();
        }} />;
        <CurrentVideo name = {this.state.selectedVideo}/>
        <Videoslist onVideoSelect = {(selectedVideo) => this.setState({selectedVideo})} name = {this.state.videos}/>
      </div>
    );
  }
}



ReactDOM.render(<Helloworld/>,document.getElementById("app"))
