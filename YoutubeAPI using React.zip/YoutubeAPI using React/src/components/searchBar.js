import React from "react";

class SearchBar extends React.Component{
  constructor(props){
    super(props)
    this.state = {
      term:""
    }
  }
  change(e){
    {
      this.setState({
      term: e.target.value
    })
    this.props.onsearch(this.state.term);
    
  }
}
  render(){
    return (
        <div className = "search-bar">
        <input value = {this.state.term} onChange = {this.change.bind(this)}/>
        </div>
  )
}
}

export default SearchBar;
