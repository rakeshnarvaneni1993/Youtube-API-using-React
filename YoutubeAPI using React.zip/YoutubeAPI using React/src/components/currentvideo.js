import React from "react";
import ReactDOM from "react-dom";


class currentvideo extends React.Component{
  constructor(props){
    super(props)
  }
  render(){
    if(!this.props.name){
      return <div>Loading.....</div>
    }
      const videoid = this.props.name.id.videoId;
      const url = "https://www.youtube.com/embed/"+videoid;
      return(
        <div className = "video-detail col-md-8">
          <div className = "embed-responsive embed-responsive-16by9">
            <iframe width="420" height="315" className = "embed-responsive-item" src = {url}></iframe>
          </div>
          <div className = "details">
            {this.props.name.snippet.title}
            {"\n"}
            {this.props.name.snippet.description}
          </div>
        </div>
      )
    }
  }






export default currentvideo;
