import React from "react";
import ReactDOM from "react-dom";

class videolistitem extends React.Component{
  constructor(props){
    super(props)

  };
  render(){
    const videoid = this.props.name.id.videoId;
    const url = "https://www.youtube.com/watch?v="+videoid;
    return (
      <li onClick = { () => this.props.onVideoSelect(this.props.name)} className = "list-group-item">
        <div className = "video-list media">
          <div className = "media-left">
            <img src = {this.props.name.snippet.thumbnails.default.url} className = "media-object" />
          </div>
          <div className = "media-body">
            <div className = "media-heading">
              {this.props.name.snippet.title}
            </div>
          </div>
        </div>
      </li>
    )
  };
}

export default videolistitem;
