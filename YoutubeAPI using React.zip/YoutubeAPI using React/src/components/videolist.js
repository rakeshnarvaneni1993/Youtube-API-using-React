import React from "react";
import Listitems from "./listitem"


class list extends React.Component{
  constructor(props){
    super(props)
  }
  render(){
      const videosItems = this.props.name.map((videos)=>{
        return <Listitems onVideoSelect = {this.props.onVideoSelect} key = {videos.etag} name = {videos} />;
      })
    return (
        <ul className = "col-md-4 list-group">
          {videosItems}
        </ul>
  )
}
}

export default list ;
